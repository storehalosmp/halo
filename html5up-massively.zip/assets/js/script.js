/* =========================================================
   DATA
   ========================================================= */
const SERVER_IP = "play.blockforge.net";

const RANKS = [
  {
    id: "miner",
    name: "Miner",
    tagline: "For players who just want more room to build.",
    price: 4.99,
    perks: [
      "2 extra claimable plots",
      "/hat and /nick commands",
      "Colored chat name tag",
      "Access to #miner Discord channel",
    ],
  },
  {
    id: "knight",
    name: "Knight",
    tagline: "Extra tools for PvP and adventuring.",
    price: 9.99,
    perks: [
      "Everything in Miner",
      "/fly in your own claim",
      "1 custom crafting recipe slot",
      "Priority queue on full servers",
      "Monthly cosmetic crate key",
    ],
  },
  {
    id: "wizard",
    name: "Wizard",
    tagline: "Enchanting perks for the serious builder.",
    price: 19.99,
    featured: true,
    badge: "Most popular",
    perks: [
      "Everything in Knight",
      "/fly anywhere on the server",
      "Personal /warp for friends to visit",
      "3 custom crafting recipe slots",
      "Exclusive wizard robe cosmetic",
      "Weekly cosmetic crate key",
    ],
  },
  {
    id: "ender",
    name: "Ender Lord",
    tagline: "The full crate. Top-tier cosmetics and access.",
    price: 34.99,
    perks: [
      "Everything in Wizard",
      "Custom particle trail",
      "Private End-themed hub plot",
      "Early access to new cosmetic drops",
      "Direct line to the build team",
      "Daily cosmetic crate key",
    ],
  },
];

// rows for the comparison table: [feature, miner, knight, wizard, ender]
// true/false render as check/dash, strings render as-is
const PERK_ROWS = [
  ["Extra claim plots", "2", "2", "4", "6"],
  ["/fly", false, "in claim", "anywhere", "anywhere"],
  ["Custom crafting recipes", false, "1", "3", "5"],
  ["Cosmetic crate keys", false, "monthly", "weekly", "daily"],
  ["Priority queue", false, true, true, true],
  ["Particle trail", false, false, false, true],
  ["Discord VIP channel", true, true, true, true],
];

const FAQS = [
  {
    q: "Do ranks give any gameplay advantage?",
    a: "No. Every perk is cosmetic, quality-of-life, or social — extra plots, /fly, crate keys, and cosmetics. Nothing sold here increases damage, drop rates, or resource gain.",
  },
  {
    q: "How fast do I get my rank after buying?",
    a: "Ranks are applied automatically within a couple of minutes of checkout. If it hasn't shown up after 10 minutes, open a ticket in Discord with your username and order confirmation.",
  },
  {
    q: "Can I upgrade from a lower rank later?",
    a: "Yes — open a ticket and you'll only be charged the price difference between your current rank and the one you're upgrading to.",
  },
  {
    q: "Are purchases refundable?",
    a: "Digital perks are non-refundable once applied to your account, except in cases of accidental duplicate purchase.",
  },
];

/* =========================================================
   RENDER: RANK CARDS
   ========================================================= */
function renderRankCards() {
  const grid = document.getElementById("rankGrid");
  grid.innerHTML = RANKS.map((rank) => `
    <article class="rank-card bevel rank-card--${rank.id} ${rank.featured ? "rank-card--featured" : ""}">
      ${rank.badge ? `<span class="rank-card__badge">${rank.badge}</span>` : ""}
      <div class="rank-card__icon" aria-hidden="true"></div>
      <h3 class="rank-card__name">${rank.name}</h3>
      <p class="rank-card__tagline">${rank.tagline}</p>
      <p class="rank-card__price">$${rank.price.toFixed(2)}<span>one-time</span></p>
      <ul class="rank-card__perks">
        ${rank.perks.map((perk) => `<li>${perk}</li>`).join("")}
      </ul>
      <button class="btn btn--primary rank-card__buy" data-rank="${rank.id}">Buy ${rank.name}</button>
    </article>
  `).join("");

  grid.querySelectorAll(".rank-card__buy").forEach((btn) => {
    btn.addEventListener("click", () => openModal(btn.dataset.rank));
  });
}

/* =========================================================
   RENDER: PERK TABLE
   ========================================================= */
function renderPerkTable() {
  const body = document.getElementById("perkTableBody");
  const cell = (value) => {
    if (value === true) return `<td class="yes">✓</td>`;
    if (value === false) return `<td class="no">—</td>`;
    return `<td>${value}</td>`;
  };
  body.innerHTML = PERK_ROWS.map((row) => {
    const [feature, ...values] = row;
    return `<tr><td>${feature}</td>${values.map(cell).join("")}</tr>`;
  }).join("");
}

/* =========================================================
   RENDER: FAQ ACCORDION
   ========================================================= */
function renderFaq() {
  const list = document.getElementById("faqList");
  list.innerHTML = FAQS.map((item, i) => `
    <div class="faq-item bevel" data-index="${i}">
      <button class="faq-item__q" aria-expanded="false">${item.q}</button>
      <div class="faq-item__a"><p>${item.a}</p></div>
    </div>
  `).join("");

  list.querySelectorAll(".faq-item").forEach((item) => {
    const question = item.querySelector(".faq-item__q");
    const answer = item.querySelector(".faq-item__a");
    question.addEventListener("click", () => {
      const isOpen = item.classList.toggle("is-open");
      question.setAttribute("aria-expanded", String(isOpen));
      answer.style.maxHeight = isOpen ? answer.scrollHeight + "px" : "0px";
    });
  });
}

/* =========================================================
   MODAL / CHECKOUT
   ========================================================= */
const modal = document.getElementById("modal");
const modalSwatch = document.getElementById("modalSwatch");
const modalEyebrow = document.getElementById("modalEyebrow");
const modalTitle = document.getElementById("modalTitle");
const modalPrice = document.getElementById("modalPrice");
const modalUsername = document.getElementById("modalUsername");
const modalConfirm = document.getElementById("modalConfirm");
let activeRank = null;

function openModal(rankId) {
  activeRank = RANKS.find((r) => r.id === rankId);
  if (!activeRank) return;

  modalSwatch.className = `modal__rank-swatch rank-card__icon rank-card--${activeRank.id}`;
  modalEyebrow.textContent = "Selected rank";
  modalTitle.textContent = activeRank.name;
  modalPrice.textContent = `$${activeRank.price.toFixed(2)}`;
  modalUsername.value = "";

  modal.classList.add("is-open");
  modal.setAttribute("aria-hidden", "false");
  setTimeout(() => modalUsername.focus(), 50);
}

function closeModal() {
  modal.classList.remove("is-open");
  modal.setAttribute("aria-hidden", "true");
  activeRank = null;
}

document.getElementById("modalClose").addEventListener("click", closeModal);
modal.addEventListener("click", (e) => {
  if (e.target === modal) closeModal();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && modal.classList.contains("is-open")) closeModal();
});

modalConfirm.addEventListener("click", () => {
  const username = modalUsername.value.trim();
  if (!username) {
    modalUsername.focus();
    showToast("Enter your Minecraft username first.");
    return;
  }
  if (!activeRank) return;

  showToast(`${activeRank.name} purchased for ${username}. This is a demo — no payment was charged.`);
  closeModal();
});

/* =========================================================
   TOAST
   ========================================================= */
let toastTimer = null;
function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 3600);
}

/* =========================================================
   IP COPY
   ========================================================= */
function copyServerIp() {
  const done = () => showToast(`Copied "${SERVER_IP}" to clipboard.`);
  const fail = () => showToast(`Server IP: ${SERVER_IP}`);

  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(SERVER_IP).then(done).catch(fail);
  } else {
    fail();
  }
}
document.getElementById("ipCopy").addEventListener("click", copyServerIp);
document.getElementById("heroIpBtn").addEventListener("click", copyServerIp);

/* =========================================================
   MOBILE NAV
   ========================================================= */
const burger = document.getElementById("burger");
const nav = document.getElementById("nav");
burger.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("is-open");
  burger.setAttribute("aria-expanded", String(isOpen));
});
nav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => nav.classList.remove("is-open"));
});

/* =========================================================
   INIT
   ========================================================= */
renderRankCards();
renderPerkTable();
renderFaq();
